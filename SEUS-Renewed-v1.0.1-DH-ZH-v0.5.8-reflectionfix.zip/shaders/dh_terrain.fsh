#version 330 compatibility
/* DRAWBUFFERS:0123 */
#include "/lib/dh_terrain_fragment.glsl"
