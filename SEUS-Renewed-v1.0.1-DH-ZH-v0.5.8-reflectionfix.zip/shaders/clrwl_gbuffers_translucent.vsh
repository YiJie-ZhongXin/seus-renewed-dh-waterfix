#version 330 compatibility
// Local SEUS/Create integration v0.5.6; original licensing retained.
#define SEUS_TRANSLUCENT
#include "/lib/create_vertex.glsl"
