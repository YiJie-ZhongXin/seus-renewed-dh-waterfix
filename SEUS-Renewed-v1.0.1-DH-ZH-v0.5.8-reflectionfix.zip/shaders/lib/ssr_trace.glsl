// View-space SSR with a short initial segment, explicit hit brackets and
// projection bounds checked before sampling. Offscreen rays return no hit.
vec4 SeusTraceReflection(vec3 normal,bool edgeClamping,float perceptualRoughness) {
    bool opaqueWater=!edgeClamping && GetMaterialMask(6,texture2D(composite,texcoord.st).b*255.0)>0.5;
    vec3 surface=convertScreenSpaceToWorldSpace(texcoord.st);
    vec3 dir=normalize(reflect(normalize(surface),normalize(normal)));
    vec3 face=cross(dFdx(surface),dFdy(surface));
    if(dot(face,-surface)<0.0) face=-face;
    // Bent shading normals must not reflect back into their own flat surface.
    if(!opaqueWater && !edgeClamping && dot(face,face)>1e-14 && dot(dir,normalize(face))<=0.0001) return vec4(0.0);
    float bias=max(0.006,-surface.z*0.0003);
    vec3 origin=surface+normal*bias;
    float lastT=0.0,lastDiff=-1e20,t=max(0.025,-surface.z*0.0006);
    float stepLength=t;
    for(int i=0;i<56;i++) {
        vec3 p=origin+dir*t;
        if(p.z>=-near || -p.z>SeusSceneFar()*1.4) break;
        vec4 clip=gbufferProjection*vec4(p,1.0);
        if(clip.w<=0.0) break;
        vec3 screen=clip.xyz/clip.w*0.5+0.5;
        if(any(lessThanEqual(screen,vec3(0.0))) || any(greaterThanEqual(screen,vec3(1.0)))) break;
        float depth=opaqueWater?SeusDepth1(depthtex1,screen.xy):SeusDepth0(gdepthtex,screen.xy);
        float sceneZ=SeusViewPosition(screen.xy,depth).z;
        float diff=sceneZ-p.z;
        if(depth<1.0 && diff*lastDiff<=0.0 && i>0) {
            float lo=lastT,hi=t;
            vec2 hitUV=screen.xy;
            float hitDiff=abs(diff);
            bool crossingForward=lastDiff<0.0;
            bool valid=true;
            for(int j=0;j<7;j++) {
                float mid=(lo+hi)*0.5;
                vec3 q=origin+dir*mid;
                vec4 c=gbufferProjection*vec4(q,1.0);
                vec3 s=c.xyz/c.w*0.5+0.5;
                if(c.w<=0.0 || any(lessThanEqual(s,vec3(0))) || any(greaterThanEqual(s,vec3(1)))) {valid=false;break;}
                float d=opaqueWater?SeusDepth1(depthtex1,s.xy):SeusDepth0(gdepthtex,s.xy);
                float delta=SeusViewPosition(s.xy,d).z-q.z;
                if(d<1.0 && ((delta>=0.0)==crossingForward)){hi=mid;hitUV=s.xy;hitDiff=abs(delta);}
                else lo=mid;
            }
            float thickness=max(0.025,-sceneZ*0.002);
            if(valid && hitDiff<=thickness && hi>bias*2.0) {
                vec2 border=min(hitUV,vec2(1.0)-hitUV);
                float weight=clamp(min(border.x,border.y)*24.0,0.0,1.0);
                vec3 colour=pow(max(texture2DLod(gaux3,hitUV,SeusReflectionLod(perceptualRoughness)).rgb,vec3(0)),vec3(2.2));
                return vec4(colour,weight);
            }
        }
        lastT=t;lastDiff=diff;
        stepLength*=1.22;
        t+=stepLength;
    }
    return vec4(0.0);
}
