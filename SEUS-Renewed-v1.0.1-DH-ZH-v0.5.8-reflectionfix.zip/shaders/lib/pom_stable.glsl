// Sprite-relative POM. mc_midTexCoord supplies the real atlas rectangle,
// including mixed-resolution resource packs and non-square atlases.
#define PARALLAX_SAMPLES 96 // Maximum POM ray samples. [32 64 96 128]
#define PARALLAX_STYLE 1 // 0: SEUS original ray proportions; 1: sprite-relative stable mode. [0 1]
#define PARALLAX_GRAZING_FADE 0.15 // Fade unstable detail at grazing angles. [0.03 0.05 0.06 0.1 0.15 0.2 0.3]

vec2 PomSpan() {
    return max(pomTile.zw * 2.0, 1.0 / vec2(atlasSize));
}

vec2 PomWrap(vec2 uv) {
    vec2 span = PomSpan();
    vec2 origin = pomTile.xy - span * 0.5;
    vec2 inset = min(0.5 / vec2(atlasSize), span * 0.25);
    return clamp(uv,
        origin + inset, origin + span - inset);
}

// A bounded face is not a periodically repeating height field. Keep the
// full ray inside its own UV rectangle, with a smooth fade near face edges.
vec2 PomBoundRay(vec2 coord, vec2 ray) {
    vec2 span = PomSpan();
    vec2 origin = pomTile.xy - span * 0.5;
    vec2 inset = min(0.5 / vec2(atlasSize), span * 0.25);
    vec2 lo = origin + inset;
    vec2 hi = origin + span - inset;
    vec2 safeCoord = clamp(coord, lo, hi);
    vec2 room = mix(safeCoord - lo, hi - safeCoord, step(vec2(0.0), ray));
    vec2 fraction = room / max(abs(ray), vec2(0.000001));
    float limit = clamp(min(fraction.x, fraction.y), 0.0, 1.0);
    // limit^2*(2-limit) <= limit; no full-depth ray can cross the boundary.
    float weight = limit * limit * (2.0 - limit);
    return ray * weight;
}

float PomVisibility(vec3 direction, vec2 dx, vec2 dy) {
    float facing = abs(direction.z);
    float angular = smoothstep(PARALLAX_GRAZING_FADE * 0.35,
        PARALLAX_GRAZING_FADE * 1.8, facing);
    #if PARALLAX_STYLE == 0
    // Retain the original SEUS derivative-distance fade. Normal oblique
    // views keep their relief; only near-tangent rays receive angle fading.
    float gradient = dot(abs(dx) + abs(dy), vec2(1.0));
    return angular * clamp(1.0 - gradient / 0.004, 0.0, 1.0);
    #else
    vec2 texels = PomSpan() * vec2(atlasSize);
    float footprint = max(length(dx * vec2(atlasSize)), length(dy * vec2(atlasSize)));
    float available = max(min(texels.x, texels.y), 1.0);
    return angular * (1.0 - smoothstep(available * 0.05, available * 0.2, footprint));
    #endif
}

vec2 PomRayScale(bool shadowRay) {
    #if PARALLAX_STYLE == 0
    // Original SEUS view step ratio: 0.001 / 0.15 = 1/150.
    // Original shadow slope: 1 / (64 / (depth * 0.5)) = depth/128.
    // Use floating-point aspect division; the old integer quotient can be 0.
    float ratio = float(atlasSize.x) / max(float(atlasSize.y), 1.0);
    return vec2(1.0, ratio) / (shadowRay ? 128.0 : 150.0);
    #else
    return PomSpan() * 0.08;
    #endif
}


// Normal/height atlases can use nearest filtering. Interpolate height only
// while magnified; retain mipmapped gradients when the texture is minified.
float PomHeight(vec2 uv, vec2 dx, vec2 dy) {
    float footprint = max(length(dx * vec2(atlasSize)), length(dy * vec2(atlasSize)));
    if (footprint >= 1.5)
        return textureGrad(normals, PomWrap(uv), dx, dy).a;
    vec2 pixel = PomWrap(uv) * vec2(atlasSize) - 0.5;
    vec2 f = fract(pixel);
    vec2 base = (floor(pixel) + 0.5) / vec2(atlasSize);
    vec2 texel = 1.0 / vec2(atlasSize);
    float a = textureLod(normals, PomWrap(base), 0.0).a;
    float b = textureLod(normals, PomWrap(base + vec2(texel.x, 0.0)), 0.0).a;
    float c = textureLod(normals, PomWrap(base + vec2(0.0, texel.y)), 0.0).a;
    float d = textureLod(normals, PomWrap(base + texel), 0.0).a;
    float filtered = mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
    return mix(filtered, textureGrad(normals, PomWrap(uv), dx, dy).a,
        smoothstep(0.75, 1.5, footprint));
}

// Limit travel to half a height texel per march step. This prevents the
// classic atlas-relative scale from skipping whole ridges at grazing angles.
float PomRayBudget(vec3 direction, float visibility, float layers) {
    vec2 ray = direction.xy / max(abs(direction.z), 0.04)
        * PomRayScale(false) * (PARALLAX_DEPTH * visibility);
    float travel = max(abs(ray.x) * float(atlasSize.x), abs(ray.y) * float(atlasSize.y));
    return min(1.0, (floor(layers) * 0.5) / max(travel, 0.0001));
}

vec2 OffsetCoord(vec2 coord, vec2 offset, int level) {
    return PomWrap(coord + offset);
}

vec2 CalculateParallaxCoord(vec2 coord, vec3 direction, out vec3 rayOffset, vec2 dx, vec2 dy) {
    rayOffset = vec3(0.0, 0.0, 1.0);
    float visibility = PomVisibility(direction, dx, dy);
    float height = PomHeight(coord, dx, dy);
    if (height >= 0.9999 || visibility < 0.001) return coord;
    vec2 ray = direction.xy / max(abs(direction.z), 0.04)
        * PomRayScale(false) * (PARALLAX_DEPTH * visibility);
    float layers = mix(float(PARALLAX_SAMPLES) * 0.35, float(PARALLAX_SAMPLES),
        1.0 - clamp(abs(direction.z), 0.0, 1.0));
    ray *= PomRayBudget(direction, visibility, layers);
    ray = PomBoundRay(coord, ray);
    float stepDepth = 1.0 / floor(layers);
    float previous = 0.0;
    float current = 0.0;
    for (int i = 0; i < PARALLAX_SAMPLES; ++i) {
        current = min(current + stepDepth, 1.0);
        height = PomHeight(coord + ray * current, dx, dy);
        if (current >= 1.0 - height || current >= 1.0) break;
        previous = current;
    }
    // Refine only the bracket containing the first heightfield intersection.
    #ifdef PARALLAX_HQ
    const int refinements = 6;
    #else
    const int refinements = 3;
    #endif
    for (int j = 0; j < refinements; ++j) {
        float middle = (previous + current) * 0.5;
        float surface = 1.0 - PomHeight(coord + ray * middle, dx, dy);
        if (middle < surface) previous = middle;
        else current = middle;
    }
    float hit = (previous + current) * 0.5;
    rayOffset = vec3(ray * hit, 1.0 - hit);
    return PomWrap(coord + ray * hit);
}

float GetParallaxShadow(vec2 coord, vec3 light, float baseHeight, vec2 dx, vec2 dy) {
    if (light.z <= 0.03 || baseHeight >= 0.999) return 1.0;
    float visibility = PomVisibility(normalize(tbnMatrix * viewPos), dx, dy);
    vec3 viewDirection = normalize(tbnMatrix * viewPos);
    float layers = mix(float(PARALLAX_SAMPLES) * 0.35, float(PARALLAX_SAMPLES),
        1.0 - clamp(abs(viewDirection.z), 0.0, 1.0));
    visibility *= PomRayBudget(viewDirection, visibility, layers);
    vec2 ray = light.xy / max(light.z, 0.04) * PomRayScale(true)
        * (PARALLAX_DEPTH * visibility);
    ray = PomBoundRay(coord, ray * (1.0 - baseHeight)) / max(1.0 - baseHeight, 0.001);
    vec2 travel = abs(ray) * vec2(atlasSize) * (1.0 - baseHeight);
    float steps = clamp(ceil(max(travel.x, travel.y) * 2.0), 24.0, float(PARALLAX_SAMPLES));
    float rise = (1.0 - baseHeight) / steps;
    float shadow = 1.0;
    for (int i = 1; i <= PARALLAX_SAMPLES; ++i) {
        if (float(i) > steps) break;
        float height = baseHeight + rise * float(i);
        vec2 uv = PomWrap(coord + ray * (height - baseHeight));
        float obstruction = PomHeight(uv, dx, dy) - height;
        shadow = min(shadow, 1.0 - visibility * smoothstep(0.015, 0.045, obstruction));
        if (shadow <= 0.001) break;
    }
    return shadow;
}
