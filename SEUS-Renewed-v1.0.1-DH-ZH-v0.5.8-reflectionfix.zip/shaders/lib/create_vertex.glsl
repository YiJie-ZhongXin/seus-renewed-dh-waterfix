attribute vec4 at_tangent;
attribute vec4 mc_Entity;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;
#define TAA_ENABLED // Match SEUS temporal projection for moving geometry.
varying vec2 scUV;
varying vec3 scNormal;
varying vec3 scTangent;
varying vec3 scBinormal;
varying vec2 scLight;
varying vec4 scColor;
varying vec3 scViewPos;
void main() {
    scUV = gl_MultiTexCoord0.xy;
    scColor = gl_Color;
    scLight = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    scNormal = normalize(gl_NormalMatrix * gl_Normal);
    vec3 t = gl_NormalMatrix * at_tangent.xyz;
    t -= scNormal * dot(t, scNormal);
    if (dot(t,t) < 0.000001) {
        vec3 axis = abs(scNormal.y) < 0.999 ? vec3(0.0,1.0,0.0) : vec3(1.0,0.0,0.0);
        t = axis - scNormal * dot(axis, scNormal);
    }
    scTangent = normalize(t);
    scBinormal = normalize(cross(scTangent, scNormal)) * (at_tangent.w < 0.0 ? -1.0 : 1.0);
    scViewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    // Explicit matrices are required: Colorwheel remaps these to Flywheel's
    // per-pass transforms, whereas the legacy ftransform() builtin is opaque.
    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
    #ifdef SEUS_SHADOW
    float r = length(gl_Position.xy);
    gl_Position.xy *= 0.95 / (0.1 + r * 0.9);
    gl_Position.z = mix(gl_Position.z, 0.5, 0.8);
    #else
    #ifdef TAA_ENABLED
    const vec2 offsets[12] = vec2[12](
        vec2(0,3),vec2(8,11),vec2(2,1),vec2(10,9),
        vec2(12,15),vec2(4,7),vec2(14,13),vec2(6,5),
        vec2(3,0),vec2(11,8),vec2(1,2),vec2(9,10));
    gl_Position.xy += (offsets[frameCounter % 12] / 8.0 - 1.0)
        / vec2(viewWidth,viewHeight) * gl_Position.w;
    #endif
    #endif
}
