/* DRAWBUFFERS:0123 */

uniform mat4 gbufferModelView;
uniform float far;
uniform sampler2D noisetex;
uniform float rainStrength;
uniform float wetness;

#define FORCE_WET_EFFECT // Match the near terrain's rain option.

in vec4 dhColor;
in vec2 dhLightmap;
in vec3 dhWorldNormal;
in vec3 dhWorldPosition;
in vec3 dhViewPosition;
flat in int dhBlockMaterial;

#include "/lib/dh_terrain_encoding.glsl"

float DhNoise3D(vec3 position)
{
    vec3 p = floor(position);
    vec3 f = fract(position);
    f = f * f * (3.0 - 2.0 * f);
    vec2 uv = p.xy + p.z * vec2(17.0, 37.0) + f.xy;
    float a = texture2D(noisetex, (uv + 0.5) / 64.0).x;
    float b = texture2D(noisetex, (uv + vec2(17.0, 37.0) + 0.5) / 64.0).x;
    return mix(a, b, f.z);
}

void main()
{
    // Do not draw textureless LOD cubes inside the normal terrain range.
    // Depth-only priority cannot protect alpha-tested holes or glass.
    // dhViewPosition is camera-relative; absolute world position is not.
    if (length(dhViewPosition) < 0.8 * far) discard;

    vec3 worldNormal = normalize(dhWorldNormal);
    vec3 viewNormal = normalize(mat3(gbufferModelView) * worldNormal);
    vec4 albedo = vec4(clamp(dhColor.rgb, 0.0, 1.0), 1.0);
    float material = 1.0;
    float emissive = 0.0;

    if (dhBlockMaterial == DH_BLOCK_LEAVES) material = 3.0;
    if (dhBlockMaterial == DH_BLOCK_SAND) material = 24.0;
    if (dhBlockMaterial == DH_BLOCK_STONE || dhBlockMaterial == DH_BLOCK_DEEPSLATE
        || dhBlockMaterial == DH_BLOCK_NETHER_STONE) material = 26.0;
    if (dhBlockMaterial == DH_BLOCK_LAVA) material = 31.0;
    if (dhBlockMaterial == DH_BLOCK_ILLUMINATED) material = 32.0;

    // DH has no resource-pack normal/specular textures. Keep diffuse LODs;
    // only SEUS's optional rain wetness contributes smoothness.
    float wet = 0.0;
    #ifdef FORCE_WET_EFFECT
    if (rainStrength > 0.01)
    {
        vec3 p = dhWorldPosition * vec3(1.0, 0.2, 1.0);
        float noise = (DhNoise3D(p) + 2.0 * DhNoise3D(p * 0.5)
            + 4.0 * DhNoise3D(p * 0.25)) / 7.0;
        wet = clamp(noise * 0.8 + 0.5, 0.0, 1.0) * 0.97;
        wet *= clamp(worldNormal.y * 0.5 + 0.5, 0.0, 1.0);
        wet *= clamp((dhLightmap.y * 1.05 - 0.9) / 0.1, 0.0, 1.0);
        wet *= wetness;
    }
    #endif
    if (material >= 30.0) wet = 0.0;
    albedo.rgb = pow(albedo.rgb, vec3(mix(1.0, 1.15, clamp(wet / 0.2, 0.0, 1.0))));

    gl_FragData[0] = albedo;
    gl_FragData[1] = vec4(DhEncodeBlockLight(dhLightmap.x), dhLightmap.y, emissive, 1.0);
    gl_FragData[2] = vec4(DhEncodeNormal(viewNormal), dhLightmap.x, 1.0);
    gl_FragData[3] = vec4(clamp(wet, 0.0, 1.0), 0.0, (material + 0.1) / 255.0, 1.0);
}
