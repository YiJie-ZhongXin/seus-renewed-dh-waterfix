// Derive an atlas-independent frame from the actual surface and UVs, including
// Flywheel rotations, mirrored faces and standalone repeating chain textures.
mat3 SeusSurfaceFrame(vec3 position, vec2 uv, vec3 suppliedNormal) {
    vec3 px=dFdx(position), py=dFdy(position);
    vec2 ux=dFdx(uv), uy=dFdy(uv);
    vec3 n=cross(px,py);
    if(dot(n,n)<1e-14) n=suppliedNormal;
    if(dot(n,n)<1e-14) n=vec3(0,0,1);
    n=normalize(n);
    if(dot(n,suppliedNormal)<0.0) n=-n;
    float det=ux.x*uy.y-ux.y*uy.x;
    vec3 t=px*uy.y-py*ux.y;
    vec3 b=py*ux.x-px*uy.x;
    if(abs(det)>1e-12 && dot(t,t)>1e-14 && dot(b,b)>1e-14){
        t*=sign(det); b*=sign(det);
        t=normalize(t-n*dot(t,n));
        // LabPBR uses DirectX Y-down; UV derivatives follow texture Y-down.
        b=normalize(b-n*dot(b,n)-t*dot(b,t));
        return mat3(t,b,n);
    }
    vec3 axis=abs(n.y)<0.99?vec3(0,1,0):vec3(1,0,0);
    t=normalize(axis-n*dot(axis,n));
    return mat3(t,normalize(cross(n,t)),n);
}
