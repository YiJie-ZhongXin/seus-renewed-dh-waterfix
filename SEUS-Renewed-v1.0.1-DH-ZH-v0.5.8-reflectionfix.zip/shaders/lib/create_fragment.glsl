#include "/Common.inc"
#include "/lib/material_compat.glsl"
#include "/lib/surface_frame.glsl"
uniform sampler2D tex;
uniform sampler2D normals;
uniform sampler2D specular;
uniform vec4 entityColor;
uniform int entityId;
varying vec2 scUV;
varying vec3 scNormal;
varying vec3 scTangent;
varying vec3 scBinormal;
varying vec2 scLight;
varying vec4 scColor;
varying vec3 scViewPos;
#ifdef SEUS_SHADOW
/* DRAWBUFFERS:01 */
#elif defined(SEUS_EFFECT)
/* DRAWBUFFERS:0 */
#elif defined(SEUS_TRANSLUCENT)
/* DRAWBUFFERS:02345 */
#else
/* DRAWBUFFERS:0123 */
#endif
vec2 ScLightmap(vec2 light) {
    return clamp(light * vec2(33.05,33.75) / 32.0 - vec2(1.05 / 32.0), 0.0, 1.0);
}
float ScEncodeTorch(float light) {
    return pow(max(exp(-(1.0-light)*10.0)-exp(-10.0),0.0),0.25);
}
void main() {
    #ifdef SEUS_NO_SHADOW
    discard;
    #endif
    // Do not infer atlas tiles or displace animated UVs. Conveyor chains may
    // use standalone repeating textures; Flywheel owns instance animation.
    vec2 dx = dFdx(scUV), dy = dFdy(scUV);
    vec4 sampleColor = textureGrad(tex, scUV, dx, dy);
    vec4 surface;
    vec2 light;
    #ifdef SEUS_NATIVE_BLOCK
    surface = sampleColor * scColor;
    if (entityId == 7002) discard;
    if (surface.a < 0.1) discard;
    surface.rgb = mix(surface.rgb,entityColor.rgb,entityColor.a);
    light = scLight;
    #else
    float materialAO;
    vec4 overlay;
    clrwl_computeFragment(sampleColor, surface, light, materialAO, overlay);
    surface.rgb = mix(surface.rgb,overlay.rgb,overlay.a);
    #endif
    vec2 mappedLight = ScLightmap(light);
    #ifdef SEUS_SHADOW
        vec3 shadowNormal = normalize(scNormal);
        float sky = clamp(light.y * (33.05/32.0) - 1.05/32.0,0.0,1.0);
        #ifdef SEUS_TRANSLUCENT
        shadowNormal = vec3(0.0);
        float skyWeight = 0.1;
        #else
        float skyWeight = sky * 0.8 + 0.2;
        #endif
        if(scNormal.z < 0.0) surface.rgb = vec3(0.0);
        gl_FragData[0] = surface;
        gl_FragData[1] = vec4(shadowNormal * 0.5 + 0.5,skyWeight);
    #elif defined(SEUS_EFFECT)
        // Blend colour only. Blending packed light/normal/material IDs corrupts
        // deferred rendering; glint, cracks and additive effects get no IDs.
        gl_FragData[0] = surface;
    #else
        vec3 geometryNormal = normalize(scNormal);
        vec3 n = SeusMaterialNormal(textureGrad(normals,scUV,dx,dy));
        if (dot(n,n) < 0.0001) n = vec3(0.0,0.0,1.0);
        n = normalize(n);
        vec3 viewNormal = normalize(SeusSurfaceFrame(scViewPos,scUV,geometryNormal) * n);
        vec4 spec = textureGrad(specular,scUV,dx,dy);
        float torch = ScEncodeTorch(mappedLight.x);
        #ifdef SEUS_TRANSLUCENT
        // Treat moving transparent meshes as SEUS glass, without water waves.
        gl_FragData[0] = vec4(0.0,0.0,0.0,0.2);
        gl_FragData[1] = vec4(EncodeNormal(geometryNormal),0.0,0.2);
        vec2 waterMappedLight = clamp(light * (33.05/32.0)-vec2(1.05/32.0),0.0,1.0);
        gl_FragData[2] = vec4(ScEncodeTorch(waterMappedLight.x),waterMappedLight.y,7.1/255.0,1.0);
        gl_FragData[3] = vec4(EncodeNormal(viewNormal),0.0,1.0);
        gl_FragData[4] = surface;
        #else
        gl_FragData[0] = surface;
        gl_FragData[1] = vec4(torch,mappedLight.y,SeusMaterialEmission(spec),1.0);
        gl_FragData[2] = vec4(EncodeNormal(viewNormal),mappedLight.x,surface.a);
        // Follow terrain's SEUS specular convention: red smoothness,
        // green metallic; blue is not used as an emission mask on machinery.
        float materialTag=1.1;
        #ifdef SEUS_NATIVE_BLOCK
        materialTag=entityId==7004?10.1:1.1;
        #endif
        gl_FragData[3] = vec4(spec.r,SeusMaterialMetallic(spec),materialTag/255.0,surface.a);
        #endif
    #endif
}
