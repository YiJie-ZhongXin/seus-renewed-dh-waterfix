/* DRAWBUFFERS:02345 */

uniform mat4 gbufferModelView;
uniform float far;
uniform sampler2D depthtex1;
uniform sampler2D noisetex;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;

#define WAVE_HEIGHT 0.75f

in vec4 dhColor;
in vec2 dhLightmap;
in vec3 dhWorldNormal;
in vec3 dhWorldPosition;
in vec3 dhViewPosition;
flat in int dhBlockMaterial;

#include "/lib/dh_terrain_encoding.glsl"

// The same noise flow, spectrum and speed as SEUS's near-water waves.
// Parallax and subpixel rain ripples are omitted on distant LOD surfaces.
float DhWaterWaves(vec3 position)
{
    float time = frameTimeCounter * 0.9;
    vec2 p = (position.xz - position.yy) / 20.0;
    p.x = -p.x;
    p += vec2(time, -time) / 40.0;
    float waves = texture2D(noisetex, p * vec2(2.0, 1.2) + vec2(0.0, p.x * 2.1)).x;
    p /= 2.1;
    p -= vec2(time / 30.0, time / 20.0);
    waves += texture2D(noisetex, p * vec2(2.0, 1.4) + vec2(0.0, -p.x * 2.1)).x * 4.1;
    p /= 1.5;
    p.x += time / 20.0;
    waves += texture2D(noisetex, p * vec2(1.0, 0.75) + vec2(0.0, p.x * 1.1)).x * 17.25;
    p /= 1.5;
    p.x -= time / 55.0;
    waves += texture2D(noisetex, p * vec2(1.0, 0.75) + vec2(0.0, -p.x * 1.7)).x * 15.25;
    p /= 1.9;
    p.x += time / 155.0;
    float wave = abs(texture2D(noisetex, p * vec2(1.0, 0.8) + vec2(0.0, -p.x * 1.7)).x * 2.0 - 1.0);
    float t = wave / 0.2;
    waves += (1.0 - (wave > 0.2 ? wave : 0.1 * t * t + 0.1)) * 29.25;
    p /= 2.0;
    p.x += time / 155.0;
    wave = abs(texture2D(noisetex, p * vec2(1.0, 0.8) + vec2(0.0, p.x * 1.7)).x * 2.0 - 1.0);
    t = wave / 0.2;
    waves += (1.0 - (wave > 0.2 ? wave : 0.1 * t * t + 0.1)) * 15.25;
    return waves / 82.1;
}

void main()
{
    // Do not draw textureless LOD cubes inside the normal terrain range.
    // Depth-only priority cannot protect alpha-tested holes or glass.
    // dhViewPosition is camera-relative; absolute world position is not.
    if (length(dhViewPosition) < 0.8 * far) discard;

    vec2 screenCoord = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    float vanillaDepth = texture2D(depthtex1, screenCoord).r;
    // The composite bridge gives valid vanilla geometry priority. Keep its
    // material buffers intact as well: mixing depths from two projections
    // here would select a different surface from the one stored in the G-buffer.
    // DH handles the overlap transition at the normal render-distance edge.
    if (vanillaDepth < 1.0) discard;

    bool isWater = dhBlockMaterial == DH_BLOCK_WATER;
    float material = isWater ? 6.0 : 7.0;
    vec3 worldNormal = normalize(dhWorldNormal);
    vec3 geometryNormal = normalize(mat3(gbufferModelView) * worldNormal);
    vec3 waveNormal = geometryNormal;

    if (isWater)
    {
        vec3 p = dhWorldPosition - vec3(0.065, 0.0, 0.065);
        float center = DhWaterWaves(p);
        vec2 gradient = vec2(center - DhWaterWaves(p + vec3(0.13, 0.0, 0.0)),
            center - DhWaterWaves(p + vec3(0.0, 0.0, 0.13)));
        gradient *= 20.0 * WAVE_HEIGHT / 13.0;
        // Distant pixels cover metres of water; suppress unresolved detail.
        float footprint = max(length(dFdx(dhWorldPosition)), length(dFdy(dhWorldPosition)));
        gradient *= 1.0 / (1.0 + footprint * 0.1);
        vec3 tangent = abs(worldNormal.y) > 0.5 ? vec3(1.0, 0.0, 0.0)
            : normalize(cross(vec3(0.0, 1.0, 0.0), worldNormal));
        vec3 bitangent = cross(tangent, worldNormal);
        vec3 worldWaveNormal = normalize(worldNormal + tangent * gradient.x + bitangent * gradient.y);
        waveNormal = normalize(mat3(gbufferModelView) * worldWaveNormal);
    }

    // 02345 is the original SEUS transparent G-buffer contract. In particular,
    // colortex4 contains the reflection/refraction normal, not colortex2.
    // DH vertices normalize light nibbles to [0,1]. Vanilla SEUS water first
    // samples at (nibble + 0.5)/16, then uses this legacy lightmap remapping.
    // In particular full skylight is ~0.9677, not 1; after the sky-light curve
    // that difference otherwise doubles the distant water-fog brightness.
    vec2 waterLightmap = clamp(((dhLightmap * 15.0 + 0.5) / 16.0)
        * (33.05 / 32.0) - vec2(1.05 / 32.0), 0.0, 1.0);
    gl_FragData[0] = vec4(0.0, 0.0, 0.0, 0.2);
    gl_FragData[1] = vec4(DhEncodeNormal(geometryNormal), 0.0, 0.2);
    gl_FragData[2] = vec4(DhEncodeBlockLight(waterLightmap.x), waterLightmap.y,
        (material + 0.1) / 255.0, 1.0);
    gl_FragData[3] = vec4(DhEncodeNormal(waveNormal), 0.0, 1.0);
    gl_FragData[4] = vec4(clamp(dhColor.rgb, 0.0, 1.0), clamp(dhColor.a, 0.0, 1.0));
}
