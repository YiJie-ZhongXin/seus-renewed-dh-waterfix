// SEUS's spherical normal encoding, with a defined value at the south pole.
vec2 DhEncodeNormal(vec3 n)
{
    n = normalize(n);
    if (n.z < -0.999999)
        return vec2(1.0, 0.5);
    return n.xy / sqrt(8.0 * n.z + 8.0) + 0.5;
}

// Terrain stores the fourth root; the deferred pass applies the final curve.
float DhEncodeBlockLight(float light)
{
    return pow(max(exp((clamp(light, 0.0, 1.0) - 1.0) * 10.0)
        - exp(-10.0), 0.0), 0.25);
}
