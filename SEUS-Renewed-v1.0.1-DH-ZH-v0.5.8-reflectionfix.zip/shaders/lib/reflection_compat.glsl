// Conservative rough-surface approximation for SEUS's single-ray SSR.
float SeusReflectionLod(float perceptualRoughness) {
    return clamp(perceptualRoughness * 6.0,0.0,6.0);
}
float SeusReflectionWeight(float dielectricWeight,float smoothness,float metallic) {
    return mix(dielectricWeight,smoothness * smoothness,metallic);
}
