// Shared DH vertex stage. Iris supplies camera-relative gl_Vertex and mini-IDs.
uniform mat4 gbufferModelView;
uniform mat4 dhProjection;
uniform vec3 cameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;

#define TAA_ENABLED // Keep the LOD projection on SEUS's normal terrain jitter.

out vec4 dhColor;
out vec2 dhLightmap;
out vec3 dhWorldNormal;
out vec3 dhWorldPosition;
out vec3 dhViewPosition;
flat out int dhBlockMaterial;

void main()
{
    vec4 viewPosition = gbufferModelView * gl_Vertex;
    gl_Position = dhProjection * viewPosition;

    #ifdef TAA_ENABLED
    // SEUS Renewed uses the first twelve entries of this Bayer sequence.
    const vec2 offsets[12] = vec2[12](
        vec2(0.0, 3.0), vec2(8.0, 11.0), vec2(2.0, 1.0), vec2(10.0, 9.0),
        vec2(12.0, 15.0), vec2(4.0, 7.0), vec2(14.0, 13.0), vec2(6.0, 5.0),
        vec2(3.0, 0.0), vec2(11.0, 8.0), vec2(1.0, 2.0), vec2(9.0, 10.0));
    vec2 jitter = (offsets[frameCounter % 12] / 8.0 - 1.0)
        / vec2(viewWidth, viewHeight);
    gl_Position.xy += jitter * gl_Position.w;
    #endif

    dhColor = gl_Color;
    // In Iris 1.7.6, both UV1 and UV2 become (lightNibble + 0.5) / 16.
    dhLightmap = clamp((gl_MultiTexCoord2.xy - vec2(0.03125))
        * (16.0 / 15.0), 0.0, 1.0);
    dhWorldNormal = gl_Normal;
    dhWorldPosition = gl_Vertex.xyz + cameraPosition;
    dhViewPosition = viewPosition.xyz;
    dhBlockMaterial = dhMaterialId;
}
