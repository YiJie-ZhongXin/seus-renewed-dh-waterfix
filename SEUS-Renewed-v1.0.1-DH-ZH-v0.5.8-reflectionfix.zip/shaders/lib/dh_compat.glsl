#ifndef SEUS_DH_COMPAT_GLSL
#define SEUS_DH_COMPAT_GLSL

// Personal-use DH bridge for SEUS Renewed. Vanilla depth stays in [0, 1].
// A DH sample is tagged as -1-depth so two different projection spaces are
// never compared or reconstructed as though they shared near/far planes.
#define DH_FOG_DENSITY 1.0 // Additional haze beyond the vanilla view distance. [0.0 0.25 0.5 1.0 1.5 2.0]
#define DH_WATER_REFLECTION 1.0 // 1.0 matches near-water reflection strength; lower values can cause a color seam. [0.0 0.25 0.5 0.75 1.0]

#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform sampler2D dhDepthTex1;
uniform mat4 dhProjectionInverse;
uniform mat4 dhPreviousProjection;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform int dhRenderDistance;
#endif

bool SeusIsDH(float depth) {
    return depth < -0.5;
}

float SeusDepth0(sampler2D vanillaDepth, vec2 uv) {
    float depth = texture2D(vanillaDepth, uv).r;
#ifdef DISTANT_HORIZONS
    if (depth >= 1.0) {
        float lodDepth = texture2D(dhDepthTex0, uv).r;
        if (lodDepth < 1.0) return -1.0 - lodDepth;
    }
#endif
    return depth;
}

float SeusDepth1(sampler2D vanillaDepth, vec2 uv) {
    float depth = texture2D(vanillaDepth, uv).r;
#ifdef DISTANT_HORIZONS
    if (depth >= 1.0) {
        float lodDepth = texture2D(dhDepthTex1, uv).r;
        if (lodDepth < 1.0) return -1.0 - lodDepth;
    }
#endif
    return depth;
}

vec4 SeusViewPosition(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view;
#ifdef DISTANT_HORIZONS
    if (SeusIsDH(depth) || depth >= 1.0) {
        clip.z = (SeusIsDH(depth) ? -1.0 - depth : 1.0) * 2.0 - 1.0;
        view = dhProjectionInverse * clip;
    } else
#endif
    {
        view = gbufferProjectionInverse * clip;
    }
    return view / view.w;
}

float SeusLinearDepth(float depth) {
#ifdef DISTANT_HORIZONS
    if (SeusIsDH(depth)) {
        float lodDepth = -1.0 - depth;
        return (dhNearPlane * dhFarPlane) /
            max(dhFarPlane - lodDepth * (dhFarPlane - dhNearPlane), 0.000001);
    }
    if (depth >= 1.0) return dhFarPlane;
#endif
    return (near * far) / max(far - depth * (far - near), 0.000001);
}

vec4 SeusPreviousClip(vec4 viewPosition, float depth, mat4 vanillaPrevious) {
#ifdef DISTANT_HORIZONS
    if (SeusIsDH(depth) || depth >= 1.0)
        return dhPreviousProjection * viewPosition;
#endif
    return vanillaPrevious * viewPosition;
}

float SeusSceneFar() {
#ifdef DISTANT_HORIZONS
    return max(far, float(dhRenderDistance));
#else
    return far;
#endif
}

float SeusFogDistance(float distanceToSurface) {
#ifdef DISTANT_HORIZONS
    // Keep close terrain unchanged and join distant haze continuously.
    float start = max(64.0, far * 0.75);
    float extra = max(distanceToSurface - start, 0.0);
    return min(distanceToSurface, start) +
        start * log(1.0 + extra * DH_FOG_DENSITY / start);
#else
    return distanceToSurface;
#endif
}

#endif
