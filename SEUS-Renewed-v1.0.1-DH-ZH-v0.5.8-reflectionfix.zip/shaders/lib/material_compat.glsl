// LabPBR decoding adapted to SEUS's existing metallic workflow.
// 0 retains legacy SEUS maps. This is not a full conductor/F0 BRDF rewrite.
#define MATERIAL_FORMAT 1 // Material texture format: 0 legacy SEUS, 1 LabPBR. [0 1]
vec3 SeusMaterialNormal(vec4 texel) {
    vec2 xy = texel.rg * 2.0 - 1.0;
    #if MATERIAL_FORMAT == 1
    // Blue stores AO, not Z. Mip filtering can put XY just outside the disk.
    // Remove the half-code bias around neutral RG 127/128.
    xy=sign(xy)*max(abs(xy)-vec2(1.0/255.0),vec2(0));
    float xy2 = dot(xy,xy);
    if (xy2 > 0.9999) xy *= sqrt(0.9999 / xy2);
    return vec3(xy,sqrt(max(1.0-dot(xy,xy),0.0001)));
    #else
    vec3 n = texel.rgb * 2.0 - 1.0;
    return dot(n,n)>0.000001 ? normalize(n) : vec3(0,0,1);
    #endif
}
float SeusMaterialMetallic(vec4 s) {
    #if MATERIAL_FORMAT == 1
    // Green below 230 is dielectric F0, not fractional metalness.
    return step(229.5/255.0,s.g);
    #else
    return s.g;
    #endif
}
float SeusMaterialEmission(vec4 s) {
    #if MATERIAL_FORMAT == 1
    // 255 is the no-emission sentinel in LabPBR 1.3.
    return s.a < 254.5/255.0 ? s.a : 0.0;
    #else
    return s.b;
    #endif
}
float SeusMaterialPorosity(vec4 s) {
    #if MATERIAL_FORMAT == 1
    return (1.0-step(64.5/255.0,s.b))*clamp(s.b*255.0/64.0,0.0,1.0);
    #else
    return s.b;
    #endif
}
