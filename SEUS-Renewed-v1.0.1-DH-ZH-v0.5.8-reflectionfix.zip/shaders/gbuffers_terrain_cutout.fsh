#version 130
#define SEUS_CUTOUT
#include "terrain_fragment.glsl"
