#version 120

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/



#include "Common.inc"


/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define TAA_SOFTNESS 0.0 // Softness of temporal anti-aliasing. Default 0.0 [0.0 0.2 0.4 0.6 0.8 1.0]
#define TAA_CURRENT_WEIGHT 0.1 // Current-frame contribution; larger values reduce trails. [0.05 0.1 0.15 0.2 0.25]
#define SHARPENING 0.0 // Sharpening of the image. Default 0.0 [0.0 0.2 0.4 0.8 1.0]

#define TAA_ENABLED // Temporal Anti-Aliasing. Utilizes multiple rendered frames to reconstruct an anti-aliased image similar to supersampling. Can cause some artifacts.
//#define TAA_AGGRESSIVE // Makes Temporal Anti-Aliasing more generously blend previous frames. This results in a more stable and smoother image, but causes more noticeable artifacts with movement.

/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* DRAWBUFFERS:467 */



uniform sampler2D gcolor;
uniform sampler2D gdepth;
uniform sampler2D gdepthtex;
uniform sampler2D gnormal;
uniform sampler2D composite;
uniform sampler2D gaux1;
uniform sampler2D gaux3;
uniform sampler2D gaux4;
uniform sampler2D noisetex;

varying vec4 texcoord;
varying vec3 lightVector;

uniform int worldTime;

uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float wetness;
uniform float aspectRatio;
uniform float frameTimeCounter;
uniform sampler2D shadowcolor;
uniform sampler2D shadowcolor1;
uniform sampler2D shadowtex1;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousProjection;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

uniform int   isEyeInWater;
uniform float eyeAltitude;
uniform ivec2 eyeBrightness;
uniform ivec2 eyeBrightnessSmooth;
uniform int   fogMode;

varying float timeSunriseSunset;
varying float timeNoon;
varying float timeMidnight;

varying vec3 colorSunlight;
varying vec3 colorSkylight;

uniform float frameTime;
uniform int frameCounter;

#include "/lib/dh_compat.glsl"


vec3 GetColor(vec2 coord)
{
	return GammaToLinear(texture2D(gnormal, coord).rgb);
}

vec3 BlurV(vec2 coord)
{

	vec3 color = vec3(0.0);

	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);


/*
	float weights[3] = float[3](0.27343750, 0.32812500, 0.03515625);
	float offsets[3] = float[3](0.00000000, 1.33333333, 3.11111111);




	color += GetColor(coord) * weights[0];

	for (int i = 1; i < 3; i++)
	{
		color += GetColor(coord + vec2(0.0, offsets[i] * 1.0) * texel) * weights[i];
		color += GetColor(coord - vec2(0.0, offsets[i] * 1.0) * texel) * weights[i];
	}
*/

	float weights[5] = float[5](0.27343750, 0.21875000, 0.10937500, 0.03125000, 0.00390625);
	float offsets[5] = float[5](0.00000000, 1.00000000, 2.00000000, 3.00000000, 4.00000000);
	
	color += GetColor(coord) * weights[0];

	for (int i = 1; i < 5; i++)
	{
		color += GetColor(coord + vec2(0.0, offsets[i] * 1.0) * texel) * weights[i];
		color += GetColor(coord - vec2(0.0, offsets[i] * 1.0) * texel) * weights[i];
	}

	return color;

	//return GetColor(coord);
}

float 	ExpToLinearDepth(in float depth)
{
    return SeusLinearDepth(depth);
}

vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
    vec2 result = coord;
    float closest = SeusLinearDepth(depth);
    minDepth = depth;
    for (int i = 0; i < 4; ++i) {
        vec2 offset = vec2(i < 2 ? 1.0 : -1.0, i == 0 || i == 2 ? 1.0 : -1.0);
        vec2 sampleUV = clamp(coord + texel * offset, texel * 0.5, 1.0 - texel * 0.5);
        float sampleDepth = SeusDepth0(gdepthtex, sampleUV);
        float linearSample = SeusLinearDepth(sampleDepth);
        if (linearSample < closest) {
            closest = linearSample;
            minDepth = sampleDepth;
            result = sampleUV;
        }
    }
    return result;
}

vec3 RGBToYUV(vec3 color)
{
	mat3 mat = 		mat3( 0.2126,  0.7152,  0.0722,
				 	-0.09991, -0.33609,  0.436,
				 	 0.615, -0.55861, -0.05639);
				 	
	return color * mat;
}

vec3 YUVToRGB(vec3 color)
{
	mat3 mat = 		mat3(1.000,  0.000,  1.28033,
				 	1.000, -0.21482, -0.38059,
				 	1.000,  2.12798,  0.000);
				 	
	return color * mat;
}

#define COLORPOW 1.0

/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main() {
    vec3 bloomColor = LinearToGamma(BlurV(texcoord.st));
    vec3 color = max(texture2D(gaux3, texcoord.st).rgb, vec3(0.0));
    vec3 origColor = color;

    #ifdef TAA_ENABLED
    vec2 resolution = vec2(viewWidth, viewHeight);
    vec2 texel = 1.0 / resolution;
    float depth = SeusDepth0(gdepthtex, texcoord.st);
    float nearDepth;
    vec2 nearFragment = GetNearFragment(texcoord.st, depth, nearDepth);

    // Reconstruct at the coordinate that supplied the foreground depth.
    // Mixing the centre coordinate with a neighbour's depth bends edge motion.
    vec4 viewPos = SeusViewPosition(nearFragment, nearDepth);
    vec4 worldPos = gbufferModelViewInverse * vec4(viewPos.xyz, 1.0);
    worldPos.xyz += cameraPosition - previousCameraPosition;
    vec4 previousView = gbufferPreviousModelView * vec4(worldPos.xyz, 1.0);
    vec4 previousClip = SeusPreviousClip(previousView, nearDepth, gbufferPreviousProjection);
    vec2 previousUV = previousClip.xy / max(previousClip.w, 0.000001) * 0.5 + 0.5;
    vec2 motion = nearFragment - previousUV;
    vec2 historyUV = texcoord.st - motion;
    bool historyValid = previousClip.w > 0.0
        && all(greaterThanEqual(historyUV, texel * 0.5))
        && all(lessThanEqual(historyUV, vec2(1.0) - texel * 0.5))
        && frameCounter > 1;
    // Never read a wrapped/opposite-edge history sample, even when rejected.
    vec3 history = texture2D(gaux4, clamp(historyUV, texel * 0.5,
        vec2(1.0) - texel * 0.5)).rgb;

    vec3 minimum = color;
    vec3 maximum = color;
    vec3 average = vec3(0.0);
    vec3 moment1 = vec3(0.0);
    vec3 moment2 = vec3(0.0);
    for (int x = -1; x <= 1; ++x) {
        for (int y = -1; y <= 1; ++y) {
            vec2 uv = clamp(texcoord.st + vec2(float(x), float(y)) * texel,
                texel * 0.5, vec2(1.0) - texel * 0.5);
            vec3 sampleColor = max(texture2D(gaux3, uv).rgb, vec3(0.0));
            minimum = min(minimum, sampleColor);
            maximum = max(maximum, sampleColor);
            average += sampleColor;
            vec3 sampleYUV = RGBToYUV(sampleColor);
            moment1 += sampleYUV;
            moment2 += sampleYUV * sampleYUV;
        }
    }
    average /= 9.0;
    vec3 mean = moment1 / 9.0;
    vec3 sigma = sqrt(max(moment2 / 9.0 - mean * mean, vec3(0.0)));
    #ifdef TAA_AGGRESSIVE
    float colorWindow = 1.9;
    float currentWeight = TAA_CURRENT_WEIGHT * 0.5;
    #else
    float colorWindow = 1.5;
    float currentWeight = TAA_CURRENT_WEIGHT;
    #endif
    history = YUVToRGB(clamp(RGBToYUV(history), mean - colorWindow * sigma,
        mean + colorWindow * sigma));
    history = clamp(history, minimum, maximum);

    // Respond to actual motion in pixels, without the old periodic fractional-
    // pixel sharpen multiplier. Retain accumulation for stationary fine detail.
    float motionPixels = length(motion * resolution);
    currentWeight = max(currentWeight, mix(TAA_CURRENT_WEIGHT, 0.25,
        smoothstep(0.5, 8.0, motionPixels)));
    #ifdef TAA_AGGRESSIVE
    currentWeight *= 0.5;
    #endif
    if (!historyValid) currentWeight = 1.0;
    color = mix(color, average, TAA_SOFTNESS);
    vec3 taa = mix(history, color, currentWeight);
    // Optional bounded sharpening; SHARPENING=0 now truly disables it.
    vec3 detail = clamp(origColor - average, vec3(-0.02), vec3(0.02));
    taa = clamp(taa + detail * SHARPENING * 0.25, minimum, maximum);
    if (depth >= 0.0 && depth < 0.7) taa = origColor;
    taa = max(taa, vec3(0.0));
    #else
    vec3 taa = color;
    #endif

    gl_FragData[0] = vec4(bloomColor, 1.0);
    gl_FragData[1] = vec4(taa, 1.0);
    gl_FragData[2] = vec4(vec3(0.0), 1.0);
}
