#version 330 compatibility
// Local SEUS/Create integration v0.5.6; original licensing retained.
#include "/lib/create_fragment.glsl"
