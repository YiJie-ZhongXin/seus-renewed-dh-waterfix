#version 330 compatibility
/* DRAWBUFFERS:02345 */
#include "/lib/dh_water_fragment.glsl"
