#version 330 compatibility
// Local SEUS/Create integration v0.5.6; original licensing retained.
#define SEUS_NATIVE_BLOCK
#include "/lib/create_fragment.glsl"
